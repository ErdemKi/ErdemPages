package com.erdem.modutils.helper;

import com.erdem.modutils.ModUtils;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class ResourceKeyHelper {

    public static class_5321<class_1792> createItemKey(String path) {
        return class_5321.method_29179(
                class_7924.field_41197,
                class_2960.method_60655(ModUtils.getModId(), path)
        );
    }

    public static class_5321<class_2248> createBlockKey(String path) {
        return class_5321.method_29179(
                class_7924.field_41254,
                class_2960.method_60655(ModUtils.getModId(), path)
        );
    }
}
