package com.erdem.modutils;

import net.fabricmc.api.ModInitializer;

public class ModUtils implements ModInitializer {
    private static String modId;

    public static void setModId(String modId) { ModUtils.modId = modId; }

    public static String getModId() { return modId; }

    @Override
    public void onInitialize() {}
}
