package com.erdem.modutils.helper;

import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

public class BlockHelper {

    public static class_2248 registerSimpleBlock(String path, class_4970.class_2251 properties) {
        class_5321<class_2248> key = ResourceKeyHelper.createBlockKey(path);

        properties.method_63500(key);

        return class_2378.method_39197(
                class_7923.field_41175,
                key,
                new class_2248(properties)
        );
    }

    public static <B extends class_2248> B registerCustomBlock(
            String path,
            Function<class_4970.class_2251, B> bFunction
    ) {
        class_5321<class_2248> key = ResourceKeyHelper.createBlockKey(path);

        class_4970.class_2251 properties = class_4970.class_2251.method_9637().method_63500(key);

        B block = bFunction.apply(properties);

        return class_2378.method_39197(
                class_7923.field_41175,
                key,
                block
        );
    }

    public static class_1747 registerBlockItem(String path, class_2248 block ,class_1792.class_1793 properties) {
        class_5321<class_1792> key = ResourceKeyHelper.createItemKey(path);

        properties.method_63686(key);

        return class_2378.method_39197(
                class_7923.field_41178,
                key,
                new class_1747(block, properties)
        );
    }
}
