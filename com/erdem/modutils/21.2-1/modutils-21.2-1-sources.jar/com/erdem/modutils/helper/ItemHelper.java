package com.erdem.modutils.helper;

import java.util.function.Function;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

public class ItemHelper {

    public static class_1792 registerSimpleItem(String path, class_1792.class_1793 properties) {
        class_5321<class_1792> key = ResourceKeyHelper.createItemKey(path);

        properties.method_63686(key);

        return class_2378.method_39197(
                class_7923.field_41178,
                key,
                new class_1792(properties)
        );
    }

    public static <I extends class_1792> I registerCustomItem(
            String path,
            Function<class_1792.class_1793, I> iFunction
    ) {
        class_5321<class_1792> key = ResourceKeyHelper.createItemKey(path);

        class_1792.class_1793 properties = new class_1792.class_1793().method_63686(key);

        I item = iFunction.apply(properties);

        return class_2378.method_39197(
                class_7923.field_41178,
                key,
                item
        );
    }
}
